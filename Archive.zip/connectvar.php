<?php
//$con=mysqli_connect("127.0.0.1","root","1324","library2");
$con=mysqli_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS,SAE_MYSQL_DB);
?>