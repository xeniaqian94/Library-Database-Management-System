<div id="footer">
  <div class="container">
  	<p class="text-muted">Today is <?php echo date("y-m-d");?>. &nbsp;&nbsp;&copy; Xenia Qian, June 2014. </p>

  </div>
</div>